import React, { Component } from "react";

const Home = () => {
    return (
       <div>
         <p>Home</p>
       </div>
    )
};

export default Home;
